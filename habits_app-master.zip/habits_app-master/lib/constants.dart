import 'dart:ui';

const kPrimaryColour = Color(0xFF2b8d12);
const kGreyTextColour = Color(0xFF757373);
const kAppBarHeight = 150.0;
const kDirectionWalkingYellow = Color(0xFFFF9900);
